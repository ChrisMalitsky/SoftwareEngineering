%This is our machine learning code, it calls a function called
%trainClassifier which was made using the app classification learner

%load the data
load data.txt;

%normalizes the data
[normdata,PS] = mapminmax(data,-1,1);

%Finds the amount of rows and columns of the data
[l, h] = size(data);

%Adds a new classification column
normdata(l,h+1) = 0;

%adds all the values for each respective decay coefficient
sumCompressorDecay = 0;
sumTurbineDecay = 0;
for r = 1:l
sumCompressorDecay = sumCompressorDecay + data(r,17)
sumTurbineDecay = sumTurbineDecay + data(r, 18)
end;

%finds the average of all the decay coefficients
AvgCompressorDecay = sumCompressorDecay/l;
AvgTurbineDecay = sumTurbineDecay/l;

%Checks the Compressor decay coefficients of the original data and puts 
%a 1 if its above average and a 0 if it is below average
for r = 1:l
    if data(r, 17) < AvgCompressorDecay
        normdata(r, 19) = 0;
    else
        normdata(r, 19) = 1;
    end
end

%p is the percentage of the data that you want to train, leaving the 
%difference as the percentage of the data you want to test
p = .7;
%this randomizes the data so that if the order matters according to the
%data it doesn't effect the outcome. Then it splits the data into two data
%sets for training and testing
tf = false(l,1)    % create logical index vector
tf(1:round(p*l)) = true
tf = tf(randperm(l))   % randomise order
dataTrainingCompressor = normdata(tf,:);
dataTestingCompressor = normdata(~tf,:);


%Saves the original testing data and then eliminates the last two columns
dataTestingWithResponse = dataTestingCompressor;
dataTestingCompressor(:,19) = [];

%Machine learns with the function we have made
[trainedClassifier, validationAccuracy] = trainClassifier(dataTraining)

%Checks the Turbine decay coefficients of the original data
%and tests it against the average and puts a 1 if it is above average 
%and a 0 if it is below average
for r = 1:l
    if data(r,18) < AvgTurbineDecay
        normdata(r,19) = 0;
    else
        normdata(r,19) = 1;
    end
end

dataTrainingTurbine = normdata(tf,:);
dataTestingTurbine = normdata(~tf,:);

%Saves the original testing data and then eliminates the last two columns
dataTestingWithResponse = dataTestingTurbine;
dataTestingTurbine(:,19) = [];

[trainedClassifier, validationAccuracy] = trainClassifier(dataTraining)

